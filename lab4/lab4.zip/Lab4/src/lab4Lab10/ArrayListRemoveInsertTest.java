package lab4Lab10;

import java.util.*;

import org.junit.After;
import org.junit.Before;

import junit.framework.TestCase;


public class ArrayListRemoveInsertTest extends TestCase {
               private ArrayListRemoveInsert alri;
               private ArrayList <Integer> al;
               @Before
               public void setUp() throws Exception
               {
            	   alri = new ArrayListRemoveInsert();
            	   al = new ArrayList <Integer> ();
               }
               
               @After
               public  void tearDown() throws Exception
               {}
               
               public void test()
               {
            	   
            	   al.add(1);
            	   al.add(2);
            	   al.add(3);
            	   al.add(4);
            	   al.add(5);
            	   al.add(1);
            	   al.add(2);
            	   alri.remove(1, al);
            	   String expected = "[2, 3, 4, 5, 2]";
            	   assertEquals(al.toString(),expected);
            	   alri.insert(2, 1, al);
            	   expected = "[2, 1, 3, 4, 5, 2, 1]";
            	   assertEquals(al.toString(),expected);
               }
	
}
