package lab4Exercise6_12;

import java.util.*;

public class FourLetterWords {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		       new FourLetterWords().run();
	}
	        public void run()
	        {   
	        	
	        	ArrayList<String> words = new ArrayList<String>();
	        	words.add("hi");
	        	words.add("hello");
	        	words.add("nice");
	        	words.add("great");
	        	words.add("fine");
	        	words.add("thanks");
	        	
	        	for (int index=0; index<words.size(); index++)     //1. using an index
	        	{
	        		String word = words.get(index);
	        		
	        		    System.out.print((word.length() == 4)? word + " " : "");
	        	}
	        	System.out.println();
	        	
	        	Iterator<String> itr = words.iterator();      //2. using an explicit iterator
	        	while(itr.hasNext())
	        	{
	        		String word = itr.next();
	        		System.out.print((word.length() == 4)? word + " " : "");
	        	}   
	        	System.out.println();

	        	for (String word : words)     //3. using an enhanced for statement
	        		System.out.print((word.length() == 4)? word + " " : "");
	        }

}
