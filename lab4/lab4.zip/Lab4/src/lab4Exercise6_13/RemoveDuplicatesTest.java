package lab4Exercise6_13;

import java.util.ArrayList;

import org.junit.After;
import org.junit.Before;

import junit.framework.TestCase;

public class RemoveDuplicatesTest extends TestCase {
	
	           private RemoveDuplicates rd;
	
	           @Before
	           public void setUp() throws Exception
	           {
	        	   rd = new RemoveDuplicates();
	           }
	           
	           @After
	           public void tearDown() throws Exception
	           {
	        	   
	           }
	           
	           public void test()
	           {
	        	   ArrayList <Integer> myList = new  ArrayList <Integer>();
	        	   myList.add(3);
	               myList.add(8);
	               myList.add(6);
	               myList.add(4);
	               myList.add(8);
	               myList.add(7);
	               myList.add(8);
	               myList.add(9);
	               myList.add(4);
	               
	               rd.uniquefy(myList);
	               String expected = "[3, 8, 6, 4, 7, 9]";
	               assertEquals(myList.toString(),expected);
	           }

}
