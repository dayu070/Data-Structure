package lab4Exercise6_13;

import java.util.*;

public class RemoveDuplicates {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
               ArrayList <Integer> myList = new  ArrayList <Integer>();
               myList.add(3);
               myList.add(8);
               myList.add(6);
               myList.add(4);
               myList.add(8);
               myList.add(7);
               myList.add(8);
               myList.add(9);
               myList.add(4);
               System.out.println(uniquefy(myList).toString());
              
               
	}
	
	
	
    public static <T> ArrayList <T> uniquefy (ArrayList <T> list)
	{
    	
    	
		for (int index=0; index<list.size()-1; index++)
		{
			
			for (int i=index+1; i<list.size(); i++)
			{
				if (list.get(index) == list.get(i))
				   list.remove(i);
			}
		}
		return list;
	}

}
