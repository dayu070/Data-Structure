package lab4Exercise6_4;

import java.util.*;

public class Hypothesis {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		new Hypothesis().run();
		
	}
	
	public void run()
	{
		ArrayList<String> original = new ArrayList<String>();
		original.add("yes");
		ArrayList<Integer> copy = (ArrayList<Integer>)original.clone();
		
		System.out.println(copy.get(0));
	}
}
